A Pen created at CodePen.io. You can find this one at http://codepen.io/mathiesjanssen/pen/ggeBKm.

 A timeline with fixed header using flexbox. Data is not correct or complete. Only for demo.